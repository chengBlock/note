// enums/Outcome.java
// (c)2020 MindView LLC: see Copyright.txt
// We make no guarantees that this code is fit for any purpose.
// Visit http://OnJava8.com for more book information.
package enums;
public enum Outcome { WIN, LOSE, DRAW }
